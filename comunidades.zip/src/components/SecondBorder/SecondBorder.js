import React from 'react';
import './SecondBorder.css'; 

function SecondBorder() {
    return(
        <div className='container-fluid SecondBorder-container'>
            <h2>Innovamos 24 horas al dia • Innovamos 24 horas al dia • Innovamos 24 horas al dia • Innovamos 24 horas al dia</h2>
        </div>
    );
}

export default SecondBorder;   