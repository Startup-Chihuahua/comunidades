import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <div className="container-fluid" id="footer">
      <div class="row align-items-start">
        <div class="col">
          <h5>SE PARTE DE NUESTRO FUTURO</h5>
          <button type="button" class="btn btn-dark">
            Unete
          </button>
        </div>
        <div class="col">
          <h5>STARUP CHIHUAHUA</h5>
          <p>
            Av. Colegio Militar 4709, Nombre de Dios, 31150 Chihuahua, Chih.
          </p>
          <p>hola@startupchihuahua.com</p>
          <p>(614) 182-2983 WPP*</p>
        </div>
        <br />
        <div class="col">
          <br />
          <img
            src={require("../../assets/StartupLogo.png")}
            alt="logo StartupChihuahua"
          />
        </div>
      </div>
    </div>
  );
}

export default Footer;
