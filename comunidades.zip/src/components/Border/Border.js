import React from 'react';
import './Border.css';

function Border() {
    return(
        <div className='container-fluid border-container'>
            <h2>El futuro es hoy • El futuro es hoy • El futuro es hoy • El futuro es hoy • El futuro es hoy • El futuro es hoy</h2>
        </div>
    );
}

export default Border;  