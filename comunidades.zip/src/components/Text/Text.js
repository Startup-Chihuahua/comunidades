import React from 'react';
import './Text.css';

function Text() {
    return(
        <div className='container-fluid main-container2'>
            <h1>"BUSCAMOS LOS UNICORNIOS DE TU CABEZA Y LOS GUIAMOS DENTRO DE UN ECOSISTEMA"</h1>
        </div>
    );
}

export default Text; 