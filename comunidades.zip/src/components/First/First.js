import React from 'react';
import './First.css';

function First() {
    return(
        <div className='container-fluid main-container'>
            <h1>El futuro<br/>empieza hoy<br/>¿Ya lo estás<br/>creando?</h1>
        </div>
    );
}

export default First; 