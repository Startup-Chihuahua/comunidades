import React from 'react';

function Meetup() {
    return(
        <div className='d-flex justify-content-center'>
            <h1>View Meetup</h1>
        </div>
    );
}

export default Meetup;  