import React from 'react';

function Eventos() {
    return(
        <div className='d-flex justify-content-center'>
            <h1>View Eventos</h1>
        </div>
    );
}

export default Eventos;  