import React from 'react';

function Ecosistema() {
    return(
        <div className='d-flex justify-content-center'> 
            <h1>View Ecosistema</h1>
        </div>
    );
}

export default Ecosistema;      