import React from 'react';

function Comunidades() {
    return(
        <div className='d-flex justify-content-center'> 
            <h1>View Conoce las Comunidades</h1>
        </div>
    );
}

export default Comunidades;    