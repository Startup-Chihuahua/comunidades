import React from 'react';

function Contactanos() {
    return(
        <div className='d-flex justify-content-center'>
            <h1>View Contáctanos</h1> 
        </div> 
    );
}

export default Contactanos;  