import React from 'react';

function Startups() {
    return(
        <div className='d-flex justify-content-center'>
            <h1>View Startups</h1>
        </div>
    );
}

export default Startups;  