import React from 'react';

function TheTeam() {
    return(
        <div className='d-flex justify-content-center'>
            <h1>View The team</h1> 
        </div>
    );
}

export default TheTeam;  