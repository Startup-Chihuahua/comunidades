
export const ROUTES = {
    HOME: '/home',
    LOGIN: '/login',
    ECOSISTEMA: '/ecosistema',
    STARTUPS: '/startups',
    MEETUP: '/meetup',
    COMUNIDADES: '/comunidades',
    THETEAM: '/theteam',
    EVENTOS: '/eventos',
    CONTACTANOS: '/contactanos' 
};
